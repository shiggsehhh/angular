package webdrivermethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class SleepExample {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://example.com");

        Thread.sleep(5000); // Waits exactly 5 seconds
        driver.findElement(By.id("myButton")).click();

        driver.quit();
    }
}
