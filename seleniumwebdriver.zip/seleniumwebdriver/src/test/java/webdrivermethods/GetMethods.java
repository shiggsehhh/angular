package webdrivermethods;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetMethods {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		//get(url)-launch web
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		Thread.sleep(5000);
		//getTitle()-title of webpage
		System.out.println(driver.getTitle());
		
		//getCurrentUrl()-return url of the page
		System.out.println(driver.getCurrentUrl());
	
		//getPageSource() - written by the server in UI format
		System.out.println(driver.getPageSource());
		
		//getWindowHandle()- return ID of the single browser window
//		String windowid=driver.getWindowHandle();
//		System.out.println("wINDOW IS IS " +windowid);
		
		//getWindowHandles()- return ID
		driver.findElement(By.partialLinkText("OrangeHRM")).click();
		Set<String> mulwindowid=driver.getWindowHandles();
		System.out.println("mulwindows are "+mulwindowid);
		
	}

}
