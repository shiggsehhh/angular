package webdrivermethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ConditionalMethods {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.nopcommerce.com/register");
        driver.manage().window().maximize();

        // Wait for page to load
        Thread.sleep(3000);

        // Check if the gender radio button is displayed and enabled
        WebElement genderMale = driver.findElement(By.id("gender-male"));
        System.out.println("Gender Male is displayed: " + genderMale.isDisplayed());
        System.out.println("Gender Male is enabled: " + genderMale.isEnabled());
        System.out.println("Gender Male is selected: " + genderMale.isSelected());

        // Select the radio button
        genderMale.click();
        System.out.println("Gender Male is selected after click: " + genderMale.isSelected());

        // Check if the Register button is displayed and enabled
        WebElement registerButton = driver.findElement(By.id("register-button"));
        System.out.println("Register button is displayed: " + registerButton.isDisplayed());
        System.out.println("Register button is enabled: " + registerButton.isEnabled());

        // Close the browser
        driver.quit();
    }
}
