package day2sellocators;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.NoSuchElementException;

public class LocatorsDemo {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.youtube.com/");
        driver.manage().window().maximize();

        // name
        driver.findElement(By.name("search_query")).sendKeys("mac");

        // id
        boolean idDisplay = driver.findElement(By.id("logo-icon")).isDisplayed();
        System.out.println("Logo displayed: " + idDisplay);

        // linktext & partiallinktext
        try {
            String linktext = driver.findElement(By.partialLinkText("Tab")).getText();
            System.out.println("Link exists: " + linktext);
        } catch (NoSuchElementException e) {
            System.out.println("Link does not exist.");
        }

        // Get all <a> tags and print their hrefs
        List<WebElement> allLinks = driver.findElements(By.tagName("a"));
        System.out.println("Total number of links: " + allLinks.size());

//        for (WebElement link : allLinks) {
//            String href = link.getAttribute("href");
//            String text = link.getText();
//            if (href != null && !href.isEmpty()) {
//                System.out.println("Text: " + text + " | Href: " + href);
//            }
//        }
        
     // classname - example using "ytd-rich-item-renderer"
//        List<WebElement> headerLinks = driver.findElements(By.className("ytd-rich-item-renderer"));
//        System.out.println("Total elements with class 'ytd-rich-item-renderer': " + headerLinks.size());
//
//        for (WebElement element : headerLinks) {
//            System.out.println("Element text: " + element.getText());
//        }

      //images
      List<WebElement> images=driver.findElements(By.tagName("img"));
      System.out.println("total number of images: "+images.size());

        driver.quit();
    }
}
