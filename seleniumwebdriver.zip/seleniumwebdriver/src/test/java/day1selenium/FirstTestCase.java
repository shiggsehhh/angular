package day1selenium;

import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.WebDriver;

/*Test Case-------Launch browser(Chrome)
 * open URL https://www.youtube.com/
 * validate title should be "Your Store"
 * close browser
 */
public class FirstTestCase {
	public static void main(String[] args) {
		//1.launch the browser(chrome)
//		ChromeDriver driver=new ChromeDriver();
		WebDriver driver=new ChromeDriver();
//		WebDriver driver=new EdgeDriver();
		
		//2.open URL https://www.youtube.com/
		driver.get("https://www.youtube.com/");
		
		//3.validate title should be "Your Store"
		String act_title=driver.getTitle();
		if(act_title.equals("YouTube")) {
			System.out.println("Test passed");
		}else {
			System.out.println("Test failed");
		}
		//4.close browser
//		driver.close();
		driver.quit();
	}
}