package pageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://practicetestautomation.com/practice-test-login/");
        
        // --- Test using POM ---
        
        // 1. Create an instance of the LoginPage, passing the driver to it.
        LoginPage loginPage = new LoginPage(driver);
        
        // 2. Use the methods from the Page Object to perform the login.
        loginPage.loginToApplication("student", "Password123");
        
        // 3. Verification still happens in the test script.
        try {
            WebElement successMessage = driver.findElement(By.xpath("//h1[text()='Logged In Successfully']"));
            if (successMessage.isDisplayed()) {
                System.out.println("Verification: PASSED - Login successful.");
            }
        } catch (Exception e) {
             System.out.println("Verification: FAILED - Login unsuccessful.");
        }
        
        Thread.sleep(2000);
        driver.quit();
    }
}

