package pageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
    
    private WebDriver driver;

    // 1. Locators: All elements for this page are stored as private By objects.
    private By usernameInput = By.id("username");
    private By passwordInput = By.id("password");
    private By submitButton = By.id("submit");

    // 2. Constructor: The constructor requires a WebDriver instance, which is passed in from the test script.
    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    // 3. Page Actions: Public methods that encapsulate the actions a user can perform on the page.
    
    /**
     * Enters the given username into the username field.
     * @param username The username to enter.
     */
    public void enterUsername(String username) {
        WebElement usernameField = driver.findElement(usernameInput);
        usernameField.sendKeys(username);
    }
    
    /**
     * Enters the given password into the password field.
     * @param password The password to enter.
     */
    public void enterPassword(String password) {
        WebElement passwordField = driver.findElement(passwordInput);
        passwordField.sendKeys(password);
    }

    /**
     * Clicks the submit button.
     */
    public void clickSubmitButton() {
        driver.findElement(submitButton).click();
    }
    
    /**
     * A single, reusable method to perform a complete login action.
     * This is a very common and useful pattern.
     * @param username The username to login with.
     * @param password The password to login with.
     */
    public void loginToApplication(String username, String password) {
        System.out.println("Attempting login with user: " + username);
        enterUsername(username);
        enterPassword(password);
        clickSubmitButton();
    }
}

