package xpath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class XPathDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/");
		driver.manage().window().maximize();
		
		//xpath
//		driver.findElement(By.xpath("//*[@id=\'small-searchterms\']")).sendKeys("poda");
		
		//xpath with multiple attributes, can also be written with 'and' 'or'
//		driver.findElement(By.xpath("//input[@name='q'][@placeholder='Search store']")).sendKeys("vanko");
		
		//xpath with text()
//		driver.findElement(By.xpath("//*[text()='Apple MacBook Pro']")).click();
//		boolean displaystatus=driver.findElement(By.xpath("//*[text()='Featured products']")).isDisplayed();
//		System.out.println(displaystatus);
//	
//		String value=driver.findElement(By.xpath("//*[text()='Featured products']")).getText();
//		System.out.println(value);
		
		//xpath with contains()
//		driver.findElement(By.xpath("//input[contains(@placeholder,'Sea')]")).sendKeys("tshirts");
//		//xpath with start-with()
		driver.findElement(By.xpath("//input[starts-with(@placeholder,'Sea')]")).sendKeys("tshirts");

		//chianed xpath
		boolean imagestatus = driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']")).isDisplayed();
		System.out.println(imagestatus);

	}

}
