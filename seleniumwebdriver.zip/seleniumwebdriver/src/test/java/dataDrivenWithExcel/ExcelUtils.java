package dataDrivenWithExcel;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;

public class ExcelUtils {

    /**
     * Reads data from an Excel file into a 2D String array.
     * @param filePath The path to the Excel file.
     * @param sheetName The name of the sheet to read from.
     * @return A 2D String array containing the data from the Excel sheet.
     * @throws IOException If there is an error reading the file.
     */
    public static String[][] getTableArray(String filePath, String sheetName) throws IOException {
        String[][] tableArray;

        FileInputStream fis = new FileInputStream(filePath);
        // Access the workbook
        XSSFWorkbook workbook = new XSSFWorkbook(fis);
        // Access the sheet
        XSSFSheet sheet = workbook.getSheet(sheetName);

        // Get total number of rows and columns
        int totalRows = sheet.getPhysicalNumberOfRows();
        int totalCols = sheet.getRow(0).getPhysicalNumberOfCells();

        // Initialize the array to hold data, excluding the header row
        tableArray = new String[totalRows - 1][totalCols];
        DataFormatter formatter = new DataFormatter(); // Handles all cell types as String

        // Start from the second row (index 1) to skip the header
        for (int i = 1; i < totalRows; i++) {
            XSSFRow row = sheet.getRow(i);
            for (int j = 0; j < totalCols; j++) {
                XSSFCell cell = row.getCell(j);
                // Use DataFormatter to get cell value as a String, preventing type issues
                tableArray[i - 1][j] = formatter.formatCellValue(cell);
            }
        }

        workbook.close();
        fis.close();

        return tableArray;
    }
}
