package dataDrivenWithExcel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.IOException;

public class DataDrivenTest {

    public static void main(String[] args) throws IOException, InterruptedException {
        
        // --- Setup Phase ---
        String filePath = "./LoginData.xlsx"; // Assumes file is in project root
        
        // Get the test data from our Excel utility
        String[][] loginData = ExcelUtils.getTableArray(filePath, "Sheet1");
        int rowCount = loginData.length;
        System.out.println("Starting data-driven test with " + rowCount + " sets of data.");
        
        // --- Execution Phase ---
        // Loop through each row of data from the Excel file
        for (int i = 0; i < rowCount; i++) {
            
            WebDriver driver = new ChromeDriver();
            driver.manage().window().maximize();
            // Use a demo site with a login form
            driver.get("https://practicetestautomation.com/practice-test-login/");
            Thread.sleep(1000);
            
            // Get username and password from the current row
            String username = loginData[i][0];
            String password = loginData[i][1];
            
            System.out.println("\n--- Test Case " + (i + 1) + " ---");
            System.out.println("Attempting login with Username: " + username + " and Password: " + password);

            // --- Test Steps ---
            driver.findElement(By.id("username")).sendKeys(username);
            driver.findElement(By.id("password")).sendKeys(password);
            driver.findElement(By.id("submit")).click();
            Thread.sleep(1000);

            // --- Verification Step ---
            // Check if login was successful or failed
            try {
                WebElement successMessage = driver.findElement(By.xpath("//h1[text()='Logged In Successfully']"));
                if (successMessage.isDisplayed()) {
                    System.out.println("Verification: PASSED - Login successful.");
                    driver.findElement(By.linkText("Log out")).click();
                }
            } catch (Exception e) {
                 WebElement errorMessage = driver.findElement(By.id("error"));
                 System.out.println("Verification: FAILED - Login unsuccessful. Error: " + errorMessage.getText());
            }
            
            Thread.sleep(1000);
            driver.quit();
        }
        
        System.out.println("\n--- Data-Driven Test Completed ---");
    }
}
