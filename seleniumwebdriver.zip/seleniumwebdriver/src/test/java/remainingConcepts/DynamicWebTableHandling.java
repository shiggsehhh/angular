package remainingConcepts;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.NoSuchElementException;

public class DynamicWebTableHandling {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://testautomationpractice.blogspot.com/");
        
        WebElement productTableElement = driver.findElement(By.id("productTable"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", productTableElement);
        Thread.sleep(1000);

        System.out.println("--- Handling Dynamic Table with Pagination ---");

        String targetProduct = "Router";
        boolean isProductFound = false;
        String productPrice = "";

        while (true) { 
            // **CORRECTED WAIT STRATEGY**: Before searching, get the text of the first product on the current page.
            String firstProductNameOnPage = driver.findElement(By.xpath("//table[@id='productTable']/tbody/tr[1]/td[2]")).getText();

            List<WebElement> productElements = driver.findElements(By.xpath("//table[@id='productTable']/tbody/tr/td[2]"));
            
            for (int i = 0; i < productElements.size(); i++) {
                if (productElements.get(i).getText().equals(targetProduct)) {
                    System.out.println("Success! Found '" + targetProduct + "' on the current page.");
                    isProductFound = true;
                    String priceXpath = String.format("//table[@id='productTable']/tbody/tr[%d]/td[3]", i + 1);
                    productPrice = driver.findElement(By.xpath(priceXpath)).getText();
                    break;
                }
            }

            if (isProductFound) {
                break; 
            }

            try {
                WebElement activePageElement = driver.findElement(By.xpath("//ul[@id='pagination']/li/a[@class='active']"));
                WebElement nextButtonListItem = activePageElement.findElement(By.xpath("./parent::li/following-sibling::li[1]/a"));
                
                System.out.println("Product not found on this page, clicking next page...");
                nextButtonListItem.click();
                
                // **THE REAL FIX**: Wait until the first product's name is DIFFERENT from the one we captured before clicking.
                // This confirms the table has been updated with new data.
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                wait.until(ExpectedConditions.not(
                    ExpectedConditions.textToBe(By.xpath("//table[@id='productTable']/tbody/tr[1]/td[2]"), firstProductNameOnPage)
                ));

            } catch (NoSuchElementException e) {
                System.out.println("Reached the last page. Product not found.");
                break;
            }
        }

        if (isProductFound) {
            System.out.println("The price for " + targetProduct + " is: " + productPrice);
        }

        Thread.sleep(2000);
        driver.quit();
    }
}
