package remainingConcepts;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;
import java.io.IOException;

public class JavascriptExecutorHandling {

    public static void main(String[] args) throws InterruptedException, IOException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://testautomationpractice.blogspot.com/");

        // Cast the driver to JavascriptExecutor to use its methods.
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // --- 1. Scrolling an Element into View ---
        System.out.println("--- Scrolling an element into view ---");
        WebElement staticTable = driver.findElement(By.xpath("//h2[text()='Static Web Table']"));
        js.executeScript("arguments[0].scrollIntoView(true);", staticTable);
        System.out.println("Scrolled to the Static Web Table.");
        Thread.sleep(2000);

        // --- 2. Scrolling Down by a Specific Pixel Amount ---
        System.out.println("\n--- Scrolling down by 500 pixels ---");
        js.executeScript("window.scrollBy(0, 500);");
        System.out.println("Scrolled down.");
        Thread.sleep(2000);
        
        // --- 3. Scrolling to the Bottom of the Page ---
        System.out.println("\n--- Scrolling to the bottom of the page ---");
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        System.out.println("Scrolled to the bottom.");
        Thread.sleep(2000);

        // --- 4. Handling File Upload (Modern, Correct Method) ---
        System.out.println("\n--- Handling File Upload ---");
        
        // First, create a dummy file to upload for the demo
        File dummyFile = new File("testUpload.txt");
        dummyFile.createNewFile();
        dummyFile.deleteOnExit(); // Clean up the file after the script finishes
        System.out.println("Created a dummy file to upload at: " + dummyFile.getAbsolutePath());

        // Locate the input element. IMPORTANT: We do not click it.
        WebElement fileInputElement = driver.findElement(By.id("singleFileInput"));
        
        // Use sendKeys to provide the absolute path of the file to the input element.
        fileInputElement.sendKeys(dummyFile.getAbsolutePath());
        System.out.println("Sent file path to the input element.");
        Thread.sleep(2000);

        // Click the submit button to see the result on the page
        driver.findElement(By.xpath("//form[@id='singleFileForm']/button")).click();
        WebElement status = driver.findElement(By.id("singleFileStatus"));
        
        // Wait for the status text to appear
        Thread.sleep(1000); 
        System.out.println("Upload status on page: " + status.getText());
        
        Thread.sleep(2000);
        driver.quit();
    }
}

