package remainingConcepts;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class AdvancedWebElementsHandling {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://testautomationpractice.blogspot.com/");
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // --- 1. Handling Broken Links ---
        System.out.println("--- Verifying Broken Links ---");
        WebElement brokenLinksSection = driver.findElement(By.id("broken-links"));
        js.executeScript("arguments[0].scrollIntoView(true);", brokenLinksSection);
        Thread.sleep(500);

        List<WebElement> links = brokenLinksSection.findElements(By.tagName("a"));
        System.out.println("Found " + links.size() + " links to verify.");

        for (WebElement link : links) {
            String url = link.getAttribute("href");
            verifyLink(url);
        }

        // --- 2. Handling SVG Elements ---
        System.out.println("\n--- Interacting with SVG Element ---");
        WebElement svgSection = driver.findElement(By.xpath("//h2[text()='SVG Elements']"));
        js.executeScript("arguments[0].scrollIntoView(true);", svgSection);
        Thread.sleep(500);

        WebElement svgCircle = driver.findElement(By.xpath("//*[name()='svg']/*[name()='circle']"));
        System.out.println("Found SVG circle. Fill color is: " + svgCircle.getAttribute("fill"));
        Thread.sleep(2000);

        // --- 3. Handling Shadow DOM (Nested) ---
        System.out.println("\n--- Interacting with Shadow DOM ---");
        WebElement shadowHost = driver.findElement(By.id("shadow_host"));
        js.executeScript("arguments[0].scrollIntoView(true);", shadowHost);
        Thread.sleep(500);

        SearchContext shadowRootLevel1 = shadowHost.getShadowRoot();
        System.out.println("Accessed the first level Shadow DOM.");

        String textLevel1 = shadowRootLevel1.findElement(By.cssSelector("span.info")).getText();
        System.out.println("Text from first Shadow DOM: " + textLevel1);

        // **THE FIX**: Changed By.id() to the more reliable By.cssSelector() for finding elements in a shadow root.
        WebElement nestedShadowHost = shadowRootLevel1.findElement(By.cssSelector("#nested_shadow_host"));
        System.out.println("Found the nested shadow host.");

        SearchContext shadowRootLevel2 = nestedShadowHost.getShadowRoot();
        System.out.println("Accessed the nested Shadow DOM.");

        String textLevel2 = shadowRootLevel2.findElement(By.cssSelector("div#nested_shadow_content > div")).getText();
        System.out.println("Text from nested Shadow DOM: " + textLevel2);
        
        Thread.sleep(2000);
        driver.quit();
    }

    // Helper method to verify a single link
    public static void verifyLink(String url) {
        if (url == null || url.isEmpty()) {
            System.out.println("URL is empty or null. Skipping verification.");
            return;
        }
        try {
            URL linkUrl = new URL(url);
            HttpURLConnection httpURLConnection = (HttpURLConnection) linkUrl.openConnection();
            httpURLConnection.setConnectTimeout(3000);
            httpURLConnection.connect();

            if (httpURLConnection.getResponseCode() >= 400) {
                System.out.println("BROKEN LINK: " + url + " - Response Code: " + httpURLConnection.getResponseCode() + " " + httpURLConnection.getResponseMessage());
            } else {
                System.out.println("VALID LINK: " + url + " - Response Code: " + httpURLConnection.getResponseCode());
            }
        } catch (IOException e) {
            System.out.println("ERROR checking link " + url + ": " + e.getMessage());
        }
    }
}
