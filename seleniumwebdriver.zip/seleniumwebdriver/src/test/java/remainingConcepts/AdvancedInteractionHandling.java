package remainingConcepts;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.Iterator;
import java.util.Set;

public class AdvancedInteractionHandling {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://testautomationpractice.blogspot.com/");

        // Create an instance of the Actions class, which we will reuse.
        Actions actions = new Actions(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // --- 1. Mouse Hover ---
        System.out.println("--- Performing Mouse Hover ---");
        WebElement hoverButton = driver.findElement(By.xpath("//button[text()='Point Me']"));
        js.executeScript("arguments[0].scrollIntoView(true);", hoverButton);
        Thread.sleep(500);
        actions.moveToElement(hoverButton).perform();
        System.out.println("Successfully hovered over the button.");
        Thread.sleep(2000);


        // --- 2. Double Click ---
        System.out.println("\n--- Performing Double Click ---");
        WebElement doubleClickButton = driver.findElement(By.xpath("//button[text()='Copy Text']"));
        js.executeScript("arguments[0].scrollIntoView(true);", doubleClickButton);
        Thread.sleep(500);
        actions.doubleClick(doubleClickButton).perform();
        WebElement field2 = driver.findElement(By.id("field2"));
        System.out.println("Text in Field2 after double click: " + field2.getAttribute("value"));
        Thread.sleep(2000);


        // --- 3. Drag and Drop ---
        System.out.println("\n--- Performing Drag and Drop ---");
        WebElement draggable = driver.findElement(By.id("draggable"));
        WebElement droppable = driver.findElement(By.id("droppable"));
        js.executeScript("arguments[0].scrollIntoView(true);", draggable);
        Thread.sleep(500);
        actions.dragAndDrop(draggable, droppable).perform();
        System.out.println("Text in droppable area after drop: " + droppable.findElement(By.tagName("p")).getText());
        Thread.sleep(2000);


        // --- 4. Slider (Keyboard and Mouse) ---
        System.out.println("\n--- Interacting with Slider ---");
        WebElement sliderHandle = driver.findElement(By.xpath("//div[@id='slider-range']/span[1]"));
        js.executeScript("arguments[0].scrollIntoView(true);", sliderHandle);
        Thread.sleep(500);
        System.out.println("Moving slider using dragAndDropBy...");
        // Move the slider handle 50 pixels to the right
        actions.dragAndDropBy(sliderHandle, 50, 0).perform();
        Thread.sleep(1000);
        System.out.println("Moving slider using Keyboard keys...");
        // Click the handle and use arrow keys
        sliderHandle.click();
        for(int i=0; i<20; i++) {
            sliderHandle.sendKeys(Keys.ARROW_LEFT);
        }
        Thread.sleep(2000);


        // --- 5. Handling New Browser Window ---
        System.out.println("\n--- Handling Multiple Windows ---");
        WebElement popupWindowsButton = driver.findElement(By.xpath("//button[text()='Popup Windows']"));
        js.executeScript("arguments[0].scrollIntoView(true);", popupWindowsButton);
        Thread.sleep(500);

        // Get the handle of the original window
        String originalWindowHandle = driver.getWindowHandle();
        System.out.println("Original Window Handle: " + originalWindowHandle);

        popupWindowsButton.click();
        Thread.sleep(2000); // Wait for new windows to open

        // Get all window handles
        Set<String> allWindowHandles = driver.getWindowHandles();
        System.out.println("Total windows open: " + allWindowHandles.size());

        Iterator<String> iterator = allWindowHandles.iterator();
        while (iterator.hasNext()) {
            String childWindowHandle = iterator.next();
            // If the handle is not the same as the original, it's a new window
            if (!originalWindowHandle.equalsIgnoreCase(childWindowHandle)) {
                driver.switchTo().window(childWindowHandle);
                System.out.println("Switched to new window with title: " + driver.getTitle());
                // You can perform actions in the new window here
                driver.close(); // Close the new window
                System.out.println("Closed the new window.");
            }
        }

        // Switch back to the original window
        driver.switchTo().window(originalWindowHandle);
        System.out.println("Switched back to original window with title: " + driver.getTitle());
        Thread.sleep(2000);


        driver.quit();
    }
}

