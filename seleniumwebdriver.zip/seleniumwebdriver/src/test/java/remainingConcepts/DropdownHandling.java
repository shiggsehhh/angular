package remainingConcepts;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import java.util.List;

public class DropdownHandling {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        // --- Handling Static Drop-down ---
        System.out.println("--- Handling Static Drop-down ---");
        driver.get("https://the-internet.herokuapp.com/dropdown");

        // 1. Locate the <select> element
        WebElement staticDropdownElement = driver.findElement(By.id("dropdown"));

        // 2. Create a Select object
        Select select = new Select(staticDropdownElement);

        // 3. Select an option. You have three ways:
        // a) By Visible Text
        System.out.println("Selecting 'Option 1' by visible text...");
        select.selectByVisibleText("Option 1");
        Thread.sleep(1000);

        // b) By Value attribute
        System.out.println("Selecting 'Option 2' by value attribute...");
        select.selectByValue("2");
        Thread.sleep(1000);

        // c) By Index (0-based)
        System.out.println("Selecting 'Option 1' by index...");
        select.selectByIndex(1);
        Thread.sleep(1000);
        System.out.println("Currently selected option: " + select.getFirstSelectedOption().getText());


        // --- Handling Auto-Suggest Drop-down ---
        System.out.println("\n--- Handling Auto-Suggest Drop-down ---");
        driver.get("https://www.google.com");

        // 1. Find the search input box and type a search term
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("Selenium");
        Thread.sleep(2000); // Wait for suggestions to load

        // 2. Suggestions are usually in a list (ul/li) or divs. Locate all suggestions.
        // This XPath finds all list items within the suggestion box.
        List<WebElement> suggestions = driver.findElements(By.xpath("//ul[@role='listbox']//li/descendant::div[@role='option']"));
        System.out.println("Total suggestions found: " + suggestions.size());

        // 3. Iterate through the suggestions and click the one you want
        String desiredSuggestion = "selenium webdriver";
        for (WebElement suggestion : suggestions) {
            System.out.println("Found suggestion: " + suggestion.getText());
            if (suggestion.getText().equalsIgnoreCase(desiredSuggestion)) {
                System.out.println("Clicking on desired suggestion: " + desiredSuggestion);
                suggestion.click();
                break; // Exit the loop once clicked
            }
        }

        Thread.sleep(2000);
        driver.quit();
    }
}
