package remainingConcepts;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.List;

public class DatePickerHandling {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://testautomationpractice.blogspot.com/");

        // Scroll down to the date picker to ensure it's in view
        WebElement datePickerInput = driver.findElement(By.id("datepicker"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", datePickerInput);
        Thread.sleep(500);

        System.out.println("--- Handling Date Picker ---");

        // 1. Click on the date picker input to open the calendar
        datePickerInput.click();
        Thread.sleep(1000); // Wait for calendar animation

        // 2. Define our target date
        String targetMonth = "October";
        String targetYear = "2025";
        String targetDay = "20";

        // 3. Loop until the target month and year are displayed
        while (true) {
            // Get the currently displayed month and year
            String displayedMonth = driver.findElement(By.className("ui-datepicker-month")).getText();
            String displayedYear = driver.findElement(By.className("ui-datepicker-year")).getText();

            // Check if the current display matches the target
            if (displayedMonth.equals(targetMonth) && displayedYear.equals(targetYear)) {
                System.out.println("Navigated to correct month and year: " + targetMonth + " " + targetYear);
                break; // Exit the loop
            }
            
            // If not a match, click the 'Next' button to move to the next month.
            // For a past date, you would have logic here to click the 'Prev' button.
            driver.findElement(By.xpath("//a[@data-handler='next']")).click();
        }

        // 4. Once the correct month is displayed, select the day
        // This XPath finds all the day elements in the calendar table.
        List<WebElement> allDays = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td/a"));
        
        for(WebElement dayElement : allDays) {
            if(dayElement.getText().equals(targetDay)) {
                System.out.println("Clicking on day: " + targetDay);
                dayElement.click();
                break; // Exit loop after clicking the day
            }
        }
        
        System.out.println("Selected Date: " + datePickerInput.getAttribute("value"));

        Thread.sleep(2000);
        driver.quit();
    }
}

