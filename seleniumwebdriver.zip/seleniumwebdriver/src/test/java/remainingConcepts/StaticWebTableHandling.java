package remainingConcepts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.List;

public class StaticWebTableHandling {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://the-internet.herokuapp.com/tables");

        System.out.println("--- Handling Static Web Table ---");

        // Locate the table. We will work with the first table on the page.
        WebElement table = driver.findElement(By.id("table1"));

        // --- Task 1: Get the number of rows and columns ---
        List<WebElement> rows = table.findElements(By.xpath(".//tr"));
        // The first row is the header, so subtract 1 for data rows
        int rowCount = rows.size() - 1; 
        System.out.println("Number of Data Rows: " + rowCount);

        List<WebElement> headers = table.findElements(By.xpath(".//th"));
        int columnCount = headers.size();
        System.out.println("Number of Columns: " + columnCount);

        // --- Task 2: Get data from a specific cell (e.g., 3rd row, 4th column - Due) ---
        // XPath: .//tr[3]/td[4] (We use tr[3] because we are looking at data rows, but in a full table tr index starts from 1)
        // Let's use a more robust way: tr[row_index]/td[column_index]
        WebElement specificCell = table.findElement(By.xpath(".//tbody/tr[3]/td[4]"));
        System.out.println("\nData from 3rd row, 4th column: " + specificCell.getText());

        // --- Task 3: Find a person's 'Due' amount by their email ---
        String targetEmail = "jdoe@hotmail.com";
        String dueAmount = "";

        // Get all data rows (skipping the header row in tbody)
        List<WebElement> dataRows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : dataRows) {
            // Find the email cell in the current row
            WebElement emailCell = row.findElement(By.xpath("./td[3]"));
            if (emailCell.getText().equals(targetEmail)) {
                System.out.println("\nFound row with email: " + targetEmail);
                // Get the 'Due' amount from the same row (4th column)
                WebElement dueCell = row.findElement(By.xpath("./td[4]"));
                dueAmount = dueCell.getText();
                break; // Exit loop after finding the match
            }
        }
        
        if (!dueAmount.isEmpty()) {
            System.out.println("The 'Due' amount for " + targetEmail + " is: " + dueAmount);
        } else {
            System.out.println("Could not find a row with the email: " + targetEmail);
        }

        // --- Task 4: Print all data from the table ---
        System.out.println("\n--- All Table Data ---");
        for(WebElement row : dataRows) {
            List<WebElement> cells = row.findElements(By.xpath("./td"));
            for(WebElement cell : cells) {
                System.out.print(cell.getText() + "\t | \t");
            }
            System.out.println(); // New line after each row
        }


        Thread.sleep(2000);
        driver.quit();
    }
}
