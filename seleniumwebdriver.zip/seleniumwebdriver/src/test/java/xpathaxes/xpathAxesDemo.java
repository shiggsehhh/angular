package xpathaxes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class xpathAxesDemo {

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.bing.com/");
        driver.manage().window().maximize();

        // 1. self axis - selects the current node
        WebElement selfElement = driver.findElement(By.xpath("//textarea[@id='sb_form_q']/self::textarea"));
        System.out.println("Self Axis: " + selfElement.getAttribute("id"));

        // 2. parent axis - selects the parent of the current node
        WebElement parentElement = driver.findElement(By.xpath("//textarea[@id='sb_form_q']/parent::*"));
        System.out.println("Parent Axis Tag: " + parentElement.getTagName());

        // 3. child axis - selects children of the current node
        WebElement childElement = driver.findElement(By.xpath("//form[@id='sb_form']/child::a"));
        System.out.println("Child Axis Tag: " + childElement.getTagName());

        // 4. ancestor axis - selects all ancestors (parent, grandparent, etc.)
        WebElement ancestorElement = driver.findElement(By.xpath("//textarea[@id='sb_form_q']/ancestor::form"));
        System.out.println("Ancestor Axis ID: " + ancestorElement.getAttribute("id"));

        // 5. descendant axis - selects all descendants (children, grandchildren, etc.)
        WebElement descendantElement = driver.findElement(By.xpath("//form[@id='sb_form']/descendant::textarea"));
        System.out.println("Descendant Axis ID: " + descendantElement.getAttribute("id"));

        // 6. following-sibling axis - selects the next sibling after the current node
        WebElement followingSibling = driver.findElement(By.xpath("//div[@id='sb_search']/following-sibling::div"));
        System.out.println("Following Sibling Class: " + followingSibling.getAttribute("class"));

        // 7. preceding-sibling axis - selects the previous sibling before the current node
        WebElement precedingSibling = driver.findElement(By.xpath("//div[@id='sb_clt']/preceding-sibling::div"));
        System.out.println("Preceding Sibling Class: " + precedingSibling.getAttribute("class"));

        driver.quit();
    }
}
