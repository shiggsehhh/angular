package com.myframework.utils;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.IOException;
import java.io.InputStream;
import com.myframework.base.BaseTest; // Import BaseTest for logging

public class ExcelUtils {
    /**
     * Reads data from an Excel file (XLSX format) and returns it as a 2D String array.
     * The file is expected to be on the classpath.
     *
     * @param excelFilePath The path to the Excel file, relative to the classpath root (e.g., "testdata/LoginData.xlsx").
     * @param sheetName The name of the sheet to read from.
     * @return A 2D String array containing the data from the Excel sheet.
     * @throws IOException If the file cannot be found or read.
     */
    public static String[][] getTableArray(String excelFilePath, String sheetName) throws IOException {
        String[][] tableArray = null;
        InputStream fis = null;
        XSSFWorkbook workbook = null;

        BaseTest.log.info("ExcelUtils: Attempting to load Excel file from classpath: " + excelFilePath);

        try {
            fis = ExcelUtils.class.getClassLoader().getResourceAsStream(excelFilePath);
            
            if (fis == null) {
                BaseTest.log.fatal("ExcelUtils: Excel file NOT FOUND on classpath: " + excelFilePath);
                throw new IOException("Excel file not found on classpath: " + excelFilePath);
            }
            BaseTest.log.info("ExcelUtils: Excel file found: " + excelFilePath);

            workbook = new XSSFWorkbook(fis);
            XSSFSheet sheet = workbook.getSheet(sheetName);

            if (sheet == null) {
                BaseTest.log.fatal("ExcelUtils: Sheet '" + sheetName + "' NOT FOUND in Excel file: " + excelFilePath);
                throw new IOException("Sheet '" + sheetName + "' not found in Excel file: " + excelFilePath);
            }
            BaseTest.log.info("ExcelUtils: Sheet '" + sheetName + "' found. Reading data...");

            int totalRows = sheet.getPhysicalNumberOfRows();
            if (totalRows <= 1) { // Check for 0 rows or only header row
                BaseTest.log.warn("ExcelUtils: Excel sheet '" + sheetName + "' has no data rows (only header or empty). Total rows: " + totalRows);
                return new String[0][0]; // Return empty array if no data rows
            }
            
            XSSFRow headerRow = sheet.getRow(0);
            if (headerRow == null) {
                BaseTest.log.fatal("ExcelUtils: Excel sheet '" + sheetName + "' has no header row. Cannot determine columns.");
                throw new IOException("Excel sheet has no header row.");
            }
            int totalCols = headerRow.getPhysicalNumberOfCells();
            BaseTest.log.info("ExcelUtils: Total rows (including header): " + totalRows + ", Total columns: " + totalCols);

            // Initialize tableArray to exclude header row (totalRows - 1 data rows)
            tableArray = new String[totalRows - 1][totalCols];
            DataFormatter formatter = new DataFormatter();

            // Start from the second row (index 1) to skip the header
            for (int i = 1; i < totalRows; i++) { 
                XSSFRow row = sheet.getRow(i);
                if (row == null) { 
                    BaseTest.log.warn("ExcelUtils: Skipping null row at index: " + i);
                    continue; // Skip null rows but continue processing
                }
                for (int j = 0; j < totalCols; j++) {
                    XSSFCell cell = row.getCell(j);
                    tableArray[i - 1][j] = (cell == null) ? "" : formatter.formatCellValue(cell);
                }
            }
            BaseTest.log.info("ExcelUtils: Successfully read " + (totalRows - 1) + " data rows from Excel.");

        } catch (IOException e) {
            BaseTest.log.fatal("ExcelUtils: FATAL Error reading Excel file: " + e.getMessage(), e);
            throw e; // Re-throw the exception to be caught by the DataProvider
        } catch (Exception e) { // Catch any other unexpected exceptions during Excel processing
            BaseTest.log.fatal("ExcelUtils: An unexpected FATAL error occurred during Excel processing: " + e.getMessage(), e);
            throw new IOException("Unexpected error during Excel processing: " + e.getMessage(), e);
        } finally {
            try {
                if (workbook != null) {
                    workbook.close();
                    BaseTest.log.debug("ExcelUtils: Workbook closed.");
                }
                if (fis != null) {
                    fis.close();
                    BaseTest.log.debug("ExcelUtils: InputStream closed.");
                }
            } catch (IOException e) {
                BaseTest.log.error("ExcelUtils: Error closing Excel resources: " + e.getMessage(), e);
            }
        }
        return tableArray;
    }
}
