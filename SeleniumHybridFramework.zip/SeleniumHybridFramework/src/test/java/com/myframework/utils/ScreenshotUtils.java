package com.myframework.utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenshotUtils {

    /**
     * Takes a screenshot of the current browser window.
     * @param driver The WebDriver instance.
     * @param screenshotName The name for the screenshot file.
     * @return The absolute path to the saved screenshot file.
     * @throws IOException If there is an error saving the file.
     */
    public static String getScreenshot(WebDriver driver, String screenshotName) throws IOException {
        String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
        
        // Ensure the driver is capable of taking screenshots
        if (!(driver instanceof TakesScreenshot)) {
            throw new UnsupportedOperationException("WebDriver does not support taking screenshots.");
        }

        TakesScreenshot ts = (TakesScreenshot) driver;
        File source = ts.getScreenshotAs(OutputType.FILE);

        // Define the destination directory for screenshots
        // It's good practice to put generated files outside src/main/resources
        // Let's put them in a 'screenshots' folder within the 'reports' directory
        String screenshotsDir = System.getProperty("user.dir") + "/reports/screenshots/";
        File dir = new File(screenshotsDir);
        if (!dir.exists()) {
            dir.mkdirs(); // Create the directory if it doesn't exist
        }

        // Define the full destination path for the screenshot file
        String destination = screenshotsDir + screenshotName + "_" + dateName + ".png";
        File finalDestination = new File(destination);
        
        // Copy the screenshot file to the destination
        FileHandler.copy(source, finalDestination);
        
        // Return the relative path for the report (or absolute if preferred by ExtentReports)
        // ExtentReports typically works well with absolute paths for screenshots
        return finalDestination.getAbsolutePath();
    }
}
