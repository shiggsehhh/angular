package com.myframework.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.myframework.base.BaseTest;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentReporterNG implements ITestListener {

    private ExtentSparkReporter sparkReporter;
    private ExtentReports extent;
    private ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();

    @Override
    public void onStart(ITestContext context) {
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
        String repName = "Test-Report-" + timeStamp + ".html";
        
        // Reports will be generated in a 'reports' folder in the project root
        // Ensure this directory exists or is created by Maven
        sparkReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "/reports/" + repName);
        
        sparkReporter.config().setDocumentTitle("Automation Test Report");
        sparkReporter.config().setReportName("Login Functionality Test Report");
        sparkReporter.config().setTheme(Theme.DARK);

        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);
        extent.setSystemInfo("Application", "Test Application");
        extent.setSystemInfo("Operating System", System.getProperty("os.name"));
        extent.setSystemInfo("User Name", System.getProperty("user.name"));
        extent.setSystemInfo("Environment", "QA");
        BaseTest.log.info("Extent Reports initialized.");
    }

    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest test = extent.createTest(result.getMethod().getMethodName());
        extentTest.set(test);
        BaseTest.log.info("Starting test: " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        extentTest.get().log(Status.PASS, "Test Passed");
        BaseTest.log.info("Test Passed: " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        extentTest.get().log(Status.FAIL, "Test Failed");
        // Log the actual exception message
        if (result.getThrowable() != null) {
            extentTest.get().log(Status.FAIL, result.getThrowable().getMessage());
            BaseTest.log.error("Test Failed: " + result.getMethod().getMethodName() + " - " + result.getThrowable().getMessage(), result.getThrowable());
        } else {
            BaseTest.log.error("Test Failed: " + result.getMethod().getMethodName() + " - No throwable message available.");
        }


        try {
            // Get the driver safely from our ThreadLocal variable in BaseTest
            WebDriver driver = BaseTest.getDriver();
            
            if (driver != null) {
                String screenshotPath = ScreenshotUtils.getScreenshot(driver, result.getMethod().getMethodName());
                // Attach the screenshot to the report
                extentTest.get().addScreenCaptureFromPath(screenshotPath, result.getMethod().getMethodName());
                BaseTest.log.info("Screenshot captured for failed test: " + result.getMethod().getMethodName());
            } else {
                BaseTest.log.warn("WebDriver is null, unable to capture screenshot for failed test: " + result.getMethod().getMethodName());
            }
        } catch (IOException e) {
            BaseTest.log.error("Failed to capture screenshot for test: " + result.getMethod().getMethodName(), e);
            e.printStackTrace(); // Print stack trace for screenshot error
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        extentTest.get().log(Status.SKIP, "Test Skipped");
        BaseTest.log.info("Test Skipped: " + result.getMethod().getMethodName());
    }

    @Override
    public void onFinish(ITestContext context) {
        extent.flush();
        BaseTest.log.info("Extent Reports flushed and finalized.");
    }
    
    // Other listener methods (can be left empty if not needed)
    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}
    @Override
    public void onTestFailedWithTimeout(ITestResult result) {}
}
