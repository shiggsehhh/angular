package com.myframework.testcases;

import com.myframework.base.BaseTest;
import com.myframework.pages.HomePage;
import com.myframework.pages.LoginPage;
import com.myframework.utils.ExcelUtils;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;

public class LoginTest extends BaseTest {

    @Test(dataProvider = "loginData", groups = {"Smoke", "Regression"})
    public void verifyLogin(String username, String password, String expectedResult) {
        log.info("Executing Login Test for user: " + username);
        
        // Get the driver from the static method in BaseTest
        WebDriver driver = getDriver(); 
        if (driver == null) {
            log.error("Driver is null in LoginTest.verifyLogin before creating LoginPage object. Test will be skipped.");
            Assert.fail("WebDriver is null, cannot proceed with test."); // Fail the test explicitly
        }

        LoginPage loginPage = new LoginPage(driver); // Pass the non-null driver

        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
        loginPage.clickSubmit();

        if (expectedResult.equalsIgnoreCase("pass")) {
            log.info("Verifying successful login.");
            HomePage homePage = new HomePage(driver); // Pass the non-null driver
            Assert.assertTrue(homePage.isLoginSuccessful(), "Success message not found!");
            Assert.assertTrue(homePage.isLogoutButtonDisplayed(), "Logout button not found!");
        } else {
            log.info("Verifying failed login.");
            String actualErrorMessage = loginPage.getErrorMessage();
            // Check for both possible error messages as per the practice site
            boolean isErrorCorrect = actualErrorMessage.contains("Your username is invalid!") || actualErrorMessage.contains("Your password is invalid!");
            Assert.assertTrue(isErrorCorrect, "The expected error message was not found! Actual: " + actualErrorMessage);
        }
    }

    @Test(groups = {"Sanity"})
    public void verifyPageTitle() {
        // Reverted to the original, case-sensitive expected title
        String expectedTitle = "Test login"; 
        // Get the driver from the static method in BaseTest
        WebDriver driver = getDriver();
        if (driver == null) {
            log.error("Driver is null in LoginTest.verifyPageTitle. Test will be skipped.");
            Assert.fail("WebDriver is null, cannot proceed with test."); // Fail the test explicitly
        }
        String actualTitle = driver.getTitle();
        log.info("Verifying page title. Expected: '" + expectedTitle + "', Actual: '" + actualTitle + "'");
        
        // Reverted to the original case-sensitive assertion
        Assert.assertTrue(actualTitle.contains(expectedTitle), "Page title does not match! Expected to contain: '" + expectedTitle + "', but was: '" + actualTitle + "'");
    }


    @DataProvider(name = "loginData")
    public Object[][] getLoginData() { // Removed 'throws IOException' to handle it internally
        log.info("DataProvider: Entering getLoginData method.");
        String filePath = "testdata/LoginData.xlsx"; 
        String sheetName = "Sheet1";
        Object[][] testData = new Object[0][0]; // Initialize with empty array

        try {
            String[][] excelData = ExcelUtils.getTableArray(filePath, sheetName);
            log.info("DataProvider: Successfully retrieved " + excelData.length + " rows from Excel.");

            testData = new Object[excelData.length][3];
            for (int i = 0; i < excelData.length; i++) {
                // Ensure row has enough columns before accessing
                if (excelData[i].length < 2) {
                    log.warn("DataProvider: Skipping row " + (i + 1) + " due to insufficient columns in Excel data.");
                    continue; // Skip this row and move to the next
                }
                testData[i][0] = excelData[i][0];
                testData[i][1] = excelData[i][1];
                // Determine expected result based on the data
                if (excelData[i][0].equals("student") && excelData[i][1].equals("Password123")) {
                    testData[i][2] = "pass";
                } else {
                    testData[i][2] = "fail";
                }
            }
        } catch (IOException e) {
            log.fatal("DataProvider: FATAL Error reading login data from Excel: " + e.getMessage(), e);
            // TestNG will mark tests as skipped if DataProvider throws a RuntimeException
            // or if it returns an empty array.
            // For now, we'll let it return an empty array if an error occurs.
            // Alternatively, you could throw a RuntimeException here:
            // throw new RuntimeException("Failed to load test data from Excel.", e);
        } catch (Exception e) {
            log.fatal("DataProvider: An unexpected FATAL error occurred in getLoginData: " + e.getMessage(), e);
            // throw new RuntimeException("Unexpected error in DataProvider.", e);
        }
        log.info("DataProvider: Exiting getLoginData method. Returning " + testData.length + " test data sets.");
        return testData;
    }
}
