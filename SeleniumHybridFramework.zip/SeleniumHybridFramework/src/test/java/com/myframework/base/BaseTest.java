package com.myframework.base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.ITestResult; // Import ITestResult
import java.lang.reflect.Method; // Import Method

import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.util.Properties;

public class BaseTest {

    // Use ThreadLocal to manage the WebDriver instance for thread safety
    public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();
    public Properties prop;
    public static final Logger log = LogManager.getLogger(BaseTest.class);

    // Static initializer block: This code runs once when the class is loaded
    static {
        System.out.println("--- System.out.println: BaseTest class is being loaded ---"); // Direct print for early debugging
        log.info("--- BaseTest class is being loaded ---");
    }

    public BaseTest() {
        System.out.println("--- System.out.println: BaseTest constructor entered ---"); // Direct print for early debugging
        try {
            prop = new Properties();
            // Load config.properties from the classpath
            // The path is relative to the classpath root (src/test/resources or src/main/resources)
            // Ensure your config.properties is located at src/test/resources/config/config.properties
            log.info("Attempting to load config.properties from classpath: config/config.properties");
            InputStream fis = getClass().getClassLoader().getResourceAsStream("config/config.properties");

            if (fis != null) {
                prop.load(fis);
                log.info("Properties file loaded successfully from classpath.");
                fis.close(); // Close the input stream
                System.out.println("--- System.out.println: config.properties loaded successfully ---");
            } else {
                String errorMessage = "config.properties file NOT FOUND on the classpath. Please ensure it's in src/test/resources/config/config.properties or src/main/resources/config/config.properties.";
                log.fatal(errorMessage);
                System.err.println("--- System.err.println: FATAL ERROR - " + errorMessage); // Direct error print
                throw new IOException(errorMessage); // Throw IOException for clarity
            }
        } catch (IOException e) {
            log.fatal("Failed to load properties file in BaseTest constructor: " + e.getMessage(), e);
            System.err.println("--- System.err.println: FATAL ERROR - Failed to load properties file in BaseTest constructor: " + e.getMessage()); // Direct error print
            // Re-throw as a runtime exception to fail early if config is critical
            throw new RuntimeException("Failed to initialize BaseTest due to missing or unreadable config file: " + e.getMessage(), e);
        }
        System.out.println("--- System.out.println: BaseTest constructor exited ---");
    }

    @BeforeMethod
    public void setup(Method method) { // Added Method parameter to log test name
        System.out.println("--- System.out.println: @BeforeMethod: Entering setup() for test: " + method.getName() + " ---"); // Direct print
        String browserName = prop.getProperty("browser");
        log.info("--- @BeforeMethod: Entering setup() for test: " + method.getName() + " ---"); // Log test method name
        log.info("Attempting to set up browser: " + browserName);
        WebDriver driver = null; // Initialize to null

        try {
            switch (browserName.toLowerCase()) {
                case "chrome":
                    WebDriverManager.chromedriver().setup();
                    driver = new ChromeDriver();
                    log.info("ChromeDriver initialized.");
                    break;
                case "firefox":
                    WebDriverManager.firefoxdriver().setup();
                    driver = new FirefoxDriver();
                    log.info("FirefoxDriver initialized.");
                    break;
                case "edge":
                    WebDriverManager.edgedriver().setup();
                    driver = new EdgeDriver();
                    log.info("EdgeDriver initialized.");
                    break;
                default:
                    log.warn("Unsupported browser specified: " + browserName + ". Defaulting to Chrome.");
                    WebDriverManager.chromedriver().setup();
                    driver = new ChromeDriver();
                    log.info("ChromeDriver initialized as default.");
                    break;
            }

            if (driver != null) {
                tlDriver.set(driver);
                log.info("WebDriver instance created and set in ThreadLocal. Driver hash: " + System.identityHashCode(driver));
                System.out.println("--- System.out.println: WebDriver set in ThreadLocal for test: " + method.getName() + " ---");
                log.info("Current driver in ThreadLocal (after set): " + tlDriver.get());

                // Ensure the driver is not null from ThreadLocal before using it
                WebDriver currentDriver = getDriver();
                if (currentDriver != null) {
                    currentDriver.manage().window().maximize();
                    int timeout = Integer.parseInt(prop.getProperty("timeout"));
                    currentDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeout));
                    currentDriver.get(prop.getProperty("url"));
                    log.info("Navigated to URL: " + prop.getProperty("url"));
                    System.out.println("--- System.out.println: Navigated to URL: " + prop.getProperty("url") + " ---");
                } else {
                    log.fatal("Driver retrieved from ThreadLocal is NULL after setup. This should not happen.");
                    System.err.println("--- System.err.println: FATAL ERROR - Driver retrieved from ThreadLocal is NULL after setup for test: " + method.getName() + " ---");
                    throw new RuntimeException("WebDriver not available after initialization in ThreadLocal.");
                }
            } else {
                log.fatal("WebDriver could not be instantiated for browser: " + browserName + ". 'driver' object is null.");
                System.err.println("--- System.err.println: FATAL ERROR - WebDriver could not be instantiated for browser: " + browserName + " for test: " + method.getName() + " ---");
                throw new RuntimeException("WebDriver instantiation failed for " + browserName);
            }
        } catch (Exception e) {
            log.fatal("Critical error during WebDriver setup in @BeforeMethod for test " + method.getName() + ": " + e.getMessage(), e);
            System.err.println("--- System.err.println: FATAL ERROR - Critical error during WebDriver setup for test " + method.getName() + ": " + e.getMessage() + " ---");
            // Ensure the test fails if setup fails
            throw new RuntimeException("Test setup failed due to WebDriver error: " + e.getMessage(), e);
        }
        log.info("--- @BeforeMethod: Exiting setup() for test: " + method.getName() + " ---"); // Log test method name
        System.out.println("--- System.out.println: @BeforeMethod: Exiting setup() for test: " + method.getName() + " ---");
    }

    /**
     * A static method to safely get the driver for the current thread.
     * @return The WebDriver instance for the current thread.
     */
    public static synchronized WebDriver getDriver() {
        WebDriver driver = tlDriver.get();
        if (driver == null) {
            log.warn("Attempted to get WebDriver from ThreadLocal, but it was null. This indicates a setup issue or incorrect test execution order.");
            System.out.println("--- System.out.println: WARN - getDriver() returned null ---");
        }
        return driver;
    }

    @AfterMethod
    public void tearDown(ITestResult result) { // Added ITestResult parameter to log test name
        System.out.println("--- System.out.println: @AfterMethod: Entering tearDown() for test: " + result.getMethod().getMethodName() + " ---"); // Direct print
        log.info("--- @AfterMethod: Entering tearDown() for test: " + result.getMethod().getMethodName() + " ---"); // Log test method name
        WebDriver driver = tlDriver.get();
        if (driver != null) {
            log.info("Quitting driver for test: " + result.getMethod().getMethodName() + ". Driver hash: " + System.identityHashCode(driver));
            driver.quit();
            log.info("Browser closed successfully for test method: " + result.getMethod().getMethodName());
            System.out.println("--- System.out.println: Browser closed for test: " + result.getMethod().getMethodName() + " ---");
            tlDriver.remove();
            log.info("Driver removed from ThreadLocal for test method: " + result.getMethod().getMethodName());
            System.out.println("--- System.out.println: Driver removed from ThreadLocal for test: " + result.getMethod().getMethodName() + " ---");
        } else {
            log.warn("No WebDriver found in ThreadLocal to quit during tearDown for test method: " + result.getMethod().getMethodName());
            System.out.println("--- System.out.println: WARN - No WebDriver to quit for test: " + result.getMethod().getMethodName() + " ---");
        }
        log.info("--- @AfterMethod: Exiting tearDown() for test: " + result.getMethod().getMethodName() + " ---"); // Log test method name
        System.out.println("--- System.out.println: @AfterMethod: Exiting tearDown() for test: " + result.getMethod().getMethodName() + " ---");
    }
}
