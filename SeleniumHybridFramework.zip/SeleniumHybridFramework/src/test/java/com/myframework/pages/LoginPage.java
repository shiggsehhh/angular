package com.myframework.pages;

import com.myframework.base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {
    private WebDriver driver;
    private WebDriverWait wait;

    private By usernameInput = By.id("username");
    private By passwordInput = By.id("password");
    private By submitButton = By.id("submit");
    private By errorDisplay = By.id("error");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void enterUsername(String username) {
        // Add explicit wait for visibility before interacting
        wait.until(ExpectedConditions.visibilityOfElementLocated(usernameInput)).sendKeys(username);
        BaseTest.log.info("Entered username: " + username);
    }

    public void enterPassword(String password) {
        // Add explicit wait for visibility before interacting
        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordInput)).sendKeys(password);
        BaseTest.log.info("Entered password.");
    }

    public void clickSubmit() {
        // Add explicit wait for clickability before interacting
        wait.until(ExpectedConditions.elementToBeClickable(submitButton)).click();
        BaseTest.log.info("Clicked submit button.");
    }

    public String getErrorMessage() {
        try {
            WebElement errorElement = wait.until(ExpectedConditions.visibilityOfElementLocated(errorDisplay));
            String message = errorElement.getText();
            BaseTest.log.info("Captured error message: " + message);
            return message;
        } catch (Exception e) {
            BaseTest.log.error("Error message element not found after waiting.", e);
            return "Error message not found."; // Return a default message if element isn't found
        }
    }
}
