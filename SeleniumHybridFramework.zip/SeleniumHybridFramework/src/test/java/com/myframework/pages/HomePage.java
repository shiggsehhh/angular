package com.myframework.pages;

import com.myframework.base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class HomePage {
    private WebDriver driver;

    // Locators
    private By successMessageHeader = By.xpath("//h1[text()='Logged In Successfully']");
    private By logoutButton = By.linkText("Log out");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    // Page Actions
    public boolean isLoginSuccessful() {
        try {
            // THE FIX: Add an explicit wait to ensure the page has loaded and the element is visible
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // 10-second timeout
            wait.until(ExpectedConditions.visibilityOfElementLocated(successMessageHeader));
            
            boolean isSuccess = driver.findElement(successMessageHeader).isDisplayed();
            BaseTest.log.info("Login success message is displayed: " + isSuccess);
            return isSuccess;
        } catch (Exception e) {
            BaseTest.log.error("Login success message was not found after waiting.", e);
            return false; // Return false if the element is not found after waiting
        }
    }

    public boolean isLogoutButtonDisplayed() {
        // It's good practice to also wait for this element
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            wait.until(ExpectedConditions.visibilityOfElementLocated(logoutButton));
            boolean isDisplayed = driver.findElement(logoutButton).isDisplayed();
            BaseTest.log.info("Logout button is displayed: " + isDisplayed);
            return isDisplayed;
        } catch (Exception e) {
            BaseTest.log.error("Logout button was not found after waiting.", e);
            return false;
        }
    }
}
