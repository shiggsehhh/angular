package com.example.genaiquoteapp;

//These are used to work with JSON data (like reading and extracting values from a JSON response).
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class QuoteGeneratorService {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${gemini.api.key}")
    private String apiKey;

    @Value("${gemini.api.url}")
    private String apiUrl;

    /**
     * Generates a quote for a given topic by calling the Gemini AI API.
     * @param topic The topic for the quote.
     * @return A quote as a String.
     */
    public String generateQuote(String topic) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            String prompt = "Generate a single, short, insightful, and unique quote about '" + topic + "'. Do not include quotation marks in the response.";
            
            // This creates the JSON body for the API request
            String requestBody = String.format(
                "{\"contents\":[{\"parts\":[{\"text\":\"%s\"}]}]}", prompt
            );
            
            HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);

            // Constructing the final URL with the API key
            String finalUrl = apiUrl + "?key=" + apiKey;

            // Making the API call
            String response = restTemplate.postForObject(finalUrl, entity, String.class);

            // Parsing the JSON response to get the generated text
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(response);
            String generatedText = root.path("candidates").get(0).path("content").path("parts").get(0).path("text").asText();

            return generatedText.trim();

        } catch (Exception e) {
            // Log the error for debugging
            System.err.println("Error calling Gemini API: " + e.getMessage());
            // Return a fallback quote if the API call fails
            return "The best way to predict the future is to create it.";
        }
    }
}

