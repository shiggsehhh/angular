package com.example.genaiquoteapp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface QuoteRepository extends JpaRepository<Quote, Long> {
    // By extending JpaRepository, we get methods like:
    // save(), findById(), findAll(), deleteById(), etc.
    // We don't need to write any implementation!
}