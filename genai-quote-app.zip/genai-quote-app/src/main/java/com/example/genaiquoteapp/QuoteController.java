package com.example.genaiquoteapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/quotes")
public class QuoteController {

    @Autowired
    private QuoteGeneratorService quoteGeneratorService;
    @Autowired
    private QuoteRepository quoteRepository;

    @PostMapping("/generate")
    public ResponseEntity<Quote> createQuote(@RequestParam String topic) {
        String content = quoteGeneratorService.generateQuote(topic);
        Quote newQuote = new Quote();
        newQuote.setTopic(topic);
        newQuote.setContent(content);
        Quote savedQuote = quoteRepository.save(newQuote);
        return ResponseEntity.ok(savedQuote);
    }

    @GetMapping
    public ResponseEntity<List<Quote>> getAllQuotes() {
        List<Quote> allQuotes = quoteRepository.findAll();
        return ResponseEntity.ok(allQuotes);
    }
}