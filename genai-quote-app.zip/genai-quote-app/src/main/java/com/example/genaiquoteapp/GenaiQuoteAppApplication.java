package com.example.genaiquoteapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean; // <-- Add this import
import org.springframework.web.client.RestTemplate; // <-- Add this import

@SpringBootApplication
public class GenaiQuoteAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(GenaiQuoteAppApplication.class, args);
    }

    // Add this method
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}