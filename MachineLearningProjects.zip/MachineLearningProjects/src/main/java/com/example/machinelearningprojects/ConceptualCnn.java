package com.example.machinelearningprojects;

import java.util.Arrays;

/**
 * A conceptual demonstration of the forward pass of a simple Convolutional Neural Network (CNN).
 * This example uses only plain Java to illustrate the mechanics of convolution and max pooling.
 * NOTE: This is for educational purposes to show the structure. It does NOT include
 * the backpropagation algorithm required for the model to actually learn.
 */
public class ConceptualCnn {

    /**
     * Performs the convolution operation.
     * Slides a filter over the input matrix and computes the dot product at each step.
     * @param input A 2D matrix representing the image or the output of a previous layer.
     * @param filter A 2D matrix (kernel) that detects features.
     * @return A new 2D matrix called a "feature map".
     */
    public static double[][] convolutionForward(double[][] input, double[][] filter) {
        int inputHeight = input.length;
        int inputWidth = input[0].length;
        int filterHeight = filter.length;
        int filterWidth = filter[0].length;

        // The output size is smaller than the input size
        int outputHeight = inputHeight - filterHeight + 1;
        int outputWidth = inputWidth - filterWidth + 1;
        double[][] output = new double[outputHeight][outputWidth];

        // Slide the filter over the input matrix
        for (int i = 0; i < outputHeight; i++) {
            for (int j = 0; j < outputWidth; j++) {
                // Apply the filter at the current position (i, j)
                double sum = 0;
                for (int m = 0; m < filterHeight; m++) {
                    for (int n = 0; n < filterWidth; n++) {
                        sum += input[i + m][j + n] * filter[m][n];
                    }
                }
                output[i][j] = sum;
            }
        }
        return output;
    }

    /**
     * Applies the Rectified Linear Unit (ReLU) activation function.
     * It simply replaces all negative values in the matrix with zero.
     * @param input The matrix to apply the function to.
     */
    public static void reluForward(double[][] input) {
        for (int i = 0; i < input.length; i++) {
            for (int j = 0; j < input[i].length; j++) {
                input[i][j] = Math.max(0, input[i][j]);
            }
        }
    }

    /**
     * Performs the Max Pooling operation.
     * Downsamples the input matrix by taking the maximum value from a window.
     * This makes the model more robust to the location of features.
     * @param input The matrix to downsample.
     * @param poolSize The size of the window (e.g., 2 for a 2x2 window).
     * @return A new, smaller 2D matrix.
     */
    public static double[][] maxPoolingForward(double[][] input, int poolSize) {
        int inputHeight = input.length;
        int inputWidth = input[0].length;

        int outputHeight = inputHeight / poolSize;
        int outputWidth = inputWidth / poolSize;
        double[][] output = new double[outputHeight][outputWidth];

        for (int i = 0; i < outputHeight; i++) {
            for (int j = 0; j < outputWidth; j++) {
                double maxVal = -Double.MAX_VALUE;
                // Find the max value in the current pooling window
                for (int m = 0; m < poolSize; m++) {
                    for (int n = 0; n < poolSize; n++) {
                        maxVal = Math.max(maxVal, input[i * poolSize + m][j * poolSize + n]);
                    }
                }
                output[i][j] = maxVal;
            }
        }
        return output;
    }

    /**
     * Helper function to print a 2D matrix to the console.
     */
    public static void printMatrix(String title, double[][] matrix) {
        System.out.println(title);
        for (double[] row : matrix) {
            System.out.println(Arrays.toString(row));
        }
        System.out.println();
    }


    public static void main(String[] args) {
        System.out.println("--- Conceptual CNN Forward Pass ---");

        // A simple 6x6 "image" with a vertical edge pattern in the middle
        double[][] image = {
            {0, 0, 10, 10, 0, 0},
            {0, 0, 10, 10, 0, 0},
            {0, 0, 10, 10, 0, 0},
            {0, 0, 10, 10, 0, 0},
            {0, 0, 10, 10, 0, 0},
            {0, 0, 10, 10, 0, 0}
        };
        printMatrix("1. Original Image (6x6):", image);

        // A 3x3 filter designed to detect vertical edges
        double[][] verticalEdgeFilter = {
            {1, 0, -1},
            {1, 0, -1},
            {1, 0, -1}
        };
        printMatrix("2. Filter/Kernel (3x3):", verticalEdgeFilter);


        // --- Step 1: Convolution Layer ---
        double[][] convolved = convolutionForward(image, verticalEdgeFilter);
        printMatrix("3. After Convolution (4x4 Feature Map):", convolved);


        // --- Step 2: Activation Function (ReLU) ---
        reluForward(convolved);
        printMatrix("4. After ReLU Activation:", convolved);


        // --- Step 3: Pooling Layer ---
        double[][] pooled = maxPoolingForward(convolved, 2);
        printMatrix("5. After 2x2 Max Pooling (2x2 Final Feature Map):", pooled);
    }
}