package com.example.machinelearningprojects;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Concept: To classify a new point, find its 'K' closest neighbors from
 * the training data and take a majority vote of their classes.
 * Goal: Classify a new (x,y) point as 'A' or 'B'.
 */
public class SimpleKNN {
    // Simple data structures for points and their distances
    record DataPoint(double x, double y, String label) {}
    record Neighbor(DataPoint point, double distance) implements Comparable<Neighbor> {
        public int compareTo(Neighbor other) { return Double.compare(this.distance, other.distance); }
    }

    // Main prediction logic
    public static String predict(DataPoint newPoint, List<DataPoint> trainingData, int k) {
        // 1. Calculate distance to all training points
        List<Neighbor> neighbors = new ArrayList<>();
        for (DataPoint p : trainingData) {
            double distance = Math.sqrt(Math.pow(p.x - newPoint.x, 2) + Math.pow(p.y - newPoint.y, 2));
            neighbors.add(new Neighbor(p, distance));
        }

        // 2. Sort by distance to find the closest
        Collections.sort(neighbors);

        // 3. Take a majority vote from the top K neighbors
        Map<String, Integer> votes = new HashMap<>();
        for (int i = 0; i < k; i++) {
            String label = neighbors.get(i).point.label;
            votes.put(label, votes.getOrDefault(label, 0) + 1);
        }

        return Collections.max(votes.entrySet(), Map.Entry.comparingByValue()).getKey();
    }

    public static void main(String[] args) {
        // Data: A list of points with known classes
        List<DataPoint> trainingData = List.of(
            new DataPoint(1.0, 1.1, "A"), new DataPoint(1.0, 1.5, "A"), new DataPoint(1.3, 1.8, "A"),
            new DataPoint(6.0, 5.5, "B"), new DataPoint(5.8, 6.3, "B"), new DataPoint(7.2, 6.0, "B")
        );

        // Point we want to classify
        DataPoint unknown = new DataPoint(1.5, 2.0,"unknown");
        int k = 3;

        String prediction = predict(unknown, trainingData, k);
        System.out.println("--- K-Nearest Neighbors ---");
        System.out.printf("The new point (%.1f, %.1f) is predicted as: %s\n", unknown.x, unknown.y, prediction);
    }
}
