package com.example.machinelearningprojects;

/**
 * A simple, self-contained SVM example using only plain Java.
 * This code does NOT use any external machine learning libraries.
 * It demonstrates the fundamental structure of an SVM for educational purposes.
 * The core training logic is simplified for clarity.
 */
public class BasicSvmExample {

    // Model parameters that would be learned during training
    private double[] weights;
    private double bias = 0;

    /**
     * A simplified training method.
     * In a real SVM, this would be a complex optimization process (like SMO).
     * Here, we use a simple gradient descent for a few iterations to find a
     * basic separating hyperplane.
     * @param X The feature data.
     * @param y The labels (-1 or 1).
     * @param learningRate How big of a step to take during optimization.
     * @param epochs How many times to loop through the training data.
     */
    public void train(double[][] X, int[] y, double learningRate, int epochs) {
        // Initialize weights and bias
        int numFeatures = X[0].length;
        this.weights = new double[numFeatures];

        System.out.println("Starting training...");

        // Basic training loop (Gradient Descent)
        for (int epoch = 0; epoch < epochs; epoch++) {
            for (int i = 0; i < X.length; i++) {
                // Condition for the hinge loss function
                if (y[i] * (dotProduct(X[i], weights) - bias) >= 1) {
                    // If the point is correctly classified, we only adjust weights slightly (regularization)
                    for (int j = 0; j < numFeatures; j++) {
                        weights[j] -= learningRate * (2 * 1.0/epochs * weights[j]);
                    }
                } else {
                    // If misclassified, we adjust weights and bias more significantly
                    for (int j = 0; j < numFeatures; j++) {
                        weights[j] -= learningRate * (2 * 1.0/epochs * weights[j] - y[i] * X[i][j]);
                    }
                    bias -= learningRate * y[i];
                }
            }
        }
        System.out.println("Training complete!");
    }

    /**
     * Predicts the class for a new data point.
     * @param x The features of the new data point.
     * @return The predicted class label (-1 or 1).
     */
    public int predict(double[] x) {
        // The decision function: sign(w • x - b)
        double decisionValue = dotProduct(x, this.weights) - this.bias;
        return (decisionValue >= 0) ? 1 : -1;
    }

    /**
     * Helper function to calculate the dot product of two vectors.
     */
    private double dotProduct(double[] a, double[] b) {
        double sum = 0;
        for (int i = 0; i < a.length; i++) {
            sum += a[i] * b[i];
        }
        return sum;
    }


    public static void main(String[] args) {

        // --- Data Setup ---
        // For this plain Java example, we'll solve a simple binary problem.
        // We'll classify between two types of flowers.

        double[][] features = {
            {5.1, 3.5}, // Class -1
            {4.9, 3.0}, // Class -1
            {7.0, 3.2}, // Class 1
            {6.4, 3.2}  // Class 1
        };

        // Labels must be -1 or 1 for this binary SVM logic.
        int[] labels = {-1, -1, 1, 1};

        String[] classNames = {"Class A", "Class B"};

        System.out.println("--- Basic SVM Example (Plain Java) ---");

        // --- Training ---
        BasicSvmExample svm = new BasicSvmExample();
        svm.train(features, labels, 0.001, 1000);

        // --- Prediction ---
        double[] newFlower = {6.5, 3.0}; // A new flower, should be similar to Class 1

        int prediction = svm.predict(newFlower);
        String predictedClassName = (prediction == 1) ? classNames[1] : classNames[0];

        // --- Results ---
        System.out.println("\nNew flower features: {6.5, 3.0}");
        System.out.println("Predicted class integer: " + prediction);
        System.out.println("Predicted class name: " + predictedClassName);
        System.out.println("------------------------------------");
    }
}
