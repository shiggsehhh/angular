package com.example.machinelearningprojects;
public class SimpleLinearRegression {

    public static void main(String[] args) {
        // Data: X = Size (sq ft), Y = Price ($)
        double[] x_sizes = { 1400, 1600, 1700, 1875, 1100, 1550, 2350, 2450, 1425, 1700 };
        double[] y_prices = { 245000, 312000, 279000, 308000, 199000, 219000, 405000, 324000, 319000, 255000 };

        int n = x_sizes.length;
        // --- Step 2: Calculate the slope (m) and intercept (b) ---
        // Formula for slope (m): m = (n * sum(xy) - sum(x) * sum(y)) / (n * sum(x^2) - (sum(x))^2)
        //double slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);

        // Formula for intercept (b): b = (sum(y) - m * sum(x)) / n

        // Calculate sums needed for the formulas
        double sumX = 0.0, sumY = 0.0, sumXY = 0.0, sumX2 = 0.0;
        for (int i = 0; i < n; i++) {
            sumX += x_sizes[i];
            sumY += y_prices[i];
            sumXY += x_sizes[i] * y_prices[i];
            sumX2 += x_sizes[i] * x_sizes[i];
        }

        // Calculate slope (m) and intercept (b) using simple formulas
        double m_slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        double b_intercept = (sumY - m_slope * sumX) / n;

        System.out.println("--- Linear Regression ---");
        System.out.printf("Learned Line: price = %.2f * size + %.2f\n", m_slope, b_intercept);

        // Make a prediction for a new house
        double newHouseSize = 2000;
        double predictedPrice = m_slope * newHouseSize + b_intercept;
        System.out.printf("Prediction for a %.0f sq ft house: $%.2f\n", newHouseSize, predictedPrice);
    }
}
