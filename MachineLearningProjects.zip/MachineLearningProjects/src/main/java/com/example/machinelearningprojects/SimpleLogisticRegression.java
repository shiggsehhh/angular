package com.example.machinelearningprojects;

public class SimpleLogisticRegression {

    // Model parameters (what we "learn")
    private static double weight0 = 0.0; // Intercept
    private static double weight1 = 0.0; // Slope

    // The S-shaped sigmoid function
    private static double sigmoid(double z) {
        return 1.0 / (1.0 + Math.exp(-z));
    }

    // The iterative learning process
    private static void fit(double[] x, double[] y, double learningRate, int epochs) {
        int n = x.length;
        for (int i = 0; i < epochs; i++) {
            double grad0 = 0;
            double grad1 = 0;
            for (int j = 0; j < n; j++) {
                double prediction = sigmoid(weight1 * x[j] + weight0);
                double error = prediction - y[j];
                grad0 += error;
                grad1 += error * x[j];
            }
            // Update weights by taking a small step
            weight0 -= learningRate * (grad0 / n);
            weight1 -= learningRate * (grad1 / n);
        }
    }

    public static void main(String[] args) {
        // Data: X = Hours Studied, Y = Pass (1) or Fail (0)
        double[] x_hours = { 0.50, 0.75, 1.00, 1.25, 1.50, 1.75, 2.00, 2.25, 2.50, 2.75, 3.00, 3.25, 3.50, 4.00, 4.25, 4.50, 4.75, 5.00, 5.50 };
        double[] y_pass = { 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1 };

        // "Train" the model
        fit(x_hours, y_pass, 0.1, 10000);

        System.out.println("--- Logistic Regression ---");
        System.out.printf("Learned weights: w0=%.3f, w1=%.3f\n", weight0, weight1);

        // Make a prediction for a new student
        double newStudentHours = 2.9;
        double probability = sigmoid(weight1 * newStudentHours + weight0);
        String result = probability >= 0.5 ? "PASS" : "FAIL";
        System.out.printf("Prediction for %.1f hours: %s (Probability: %.2f%%)\n", newStudentHours, result, probability*100);
    }
}
