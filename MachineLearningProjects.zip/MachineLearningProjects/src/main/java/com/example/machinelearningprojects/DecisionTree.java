package com.example.machinelearningprojects;
import java.util.Map;

/**
 * Concept: A flowchart of "if-then-else" questions that guide to a final decision.
 * The 'learning' part (not shown here) is to find the best questions. This
 * example shows how a pre-built tree makes predictions.
 * Goal: Decide "Yes" or "No" to playing tennis based on weather.
 */
public class DecisionTree {

    // The main prediction logic that walks down the flowchart
    public static String classify(Map<String, String> data) {
        String outlook = data.get("Outlook");

        if ("Overcast".equals(outlook)) {
            return "Yes"; // Leaf node
        } else if ("Sunny".equals(outlook)) {
            // Decision node: ask another question
            String humidity = data.get("Humidity");
            if ("High".equals(humidity)) {
                return "No"; // Leaf node
            } else { // Normal humidity
                return "Yes"; // Leaf node
            }
        } else if ("Rain".equals(outlook)) {
            // Decision node: ask another question
            String wind = data.get("Wind");
            if ("Strong".equals(wind)) {
                return "No"; // Leaf node
            } else { // Weak wind
                return "Yes"; // Leaf node
            }
        }
        return "Unknown"; // Default case
    }

    public static void main(String[] args) {
        // Data for a new day we want to classify
        Map<String, String> newDay = Map.of(
            "Outlook", "Sunny",
            "Humidity", "High",
            "Wind", "Weak"
        );
        
        String decision = classify(newDay);
        System.out.println("--- Decision Tree ---");
        System.out.println("New Day: " + newDay);
        System.out.println("Decision to Play Tennis: " + decision);

        // Another example
        Map<String, String> anotherDay = Map.of("Outlook", "Rain", "Wind", "Weak");
        System.out.println("\nNew Day: " + anotherDay);
        System.out.println("Decision to Play Tennis: " + classify(anotherDay));
    }
}
