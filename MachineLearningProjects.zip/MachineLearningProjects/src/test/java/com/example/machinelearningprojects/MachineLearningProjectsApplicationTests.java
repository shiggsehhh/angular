package com.example.machinelearningprojects;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MachineLearningProjectsApplicationTests {

	@Test
	void contextLoads() {
	}

}
