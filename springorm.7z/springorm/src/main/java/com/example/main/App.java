package com.example.main;

import com.example.config.AppConfig;
import com.example.dao.UserDao;
import com.example.entity.User;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public class App {

    public static void main(String[] args) {

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        UserDao userDao = context.getBean(UserDao.class);

        // Insert user inside transaction
//        context.getBeanFactory().createBean(TransactionRunner.class).run(() -> {
//            User user = new User("karthik", "ramachandran@example.com");
//            userDao.saveUser(user);
//            System.out.println("Saved user: " + user);
//        });

        // Fetch and print all users inside transaction
        context.getBeanFactory().createBean(TransactionRunner.class).run(() -> {
            List<User> users = userDao.getAllUsers();
            System.out.println("All users:");
            users.forEach(System.out::println);
        });
        
        context.getBeanFactory().createBean(TransactionRunner.class).run(() -> {
            User user = userDao.getUserByEmail("shivanii@example.com");
            System.out.println("Fetched by email: " + user);
        });


        context.close();
    }

    public static class TransactionRunner {
        @Transactional
        public void run(Runnable action) {
            action.run();
        }
    }
}
