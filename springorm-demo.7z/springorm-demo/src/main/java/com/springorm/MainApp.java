package com.springorm;

import com.springorm.dao.StudentDao;
import com.springorm.entity.Student;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        StudentDao studentDao = context.getBean("studentDao", StudentDao.class);

        Scanner scanner = new Scanner(System.in);
        boolean go = true;

        while (go) {
            System.out.println("\n----- Student ORM Operations -----");
            System.out.println("1. Insert Student");
            System.out.println("2. Get Student by ID");
            System.out.println("3. Get All Students");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume newline

            switch (choice) {
            case 1:
                Student student = new Student();
                System.out.print("Enter Name: ");
                student.setName(scanner.nextLine());
                System.out.print("Enter City: ");
                student.setCity(scanner.nextLine());
                int id = studentDao.insert(student);
                System.out.println("✅ Student inserted with ID: " + id);
                break;

            case 2:
                System.out.print("Enter Student ID: ");
                int getId = scanner.nextInt();
                Student s = studentDao.getStudent(getId);
                if (s != null)
                    System.out.println("🎓 " + s);
                else
                    System.out.println("❌ Student not found.");
                break;

            case 3:
                List<Student> students = studentDao.getAllStudents();
                System.out.println("📋 All Students:");
                for (Student std : students) {
                    System.out.println(std);
                }
                break;

            case 4:
                System.out.print("Enter ID to update: ");
                int updateId = scanner.nextInt();
                scanner.nextLine(); // consume newline
                Student updateStudent = studentDao.getStudent(updateId);
                if (updateStudent != null) {
                    System.out.print("Enter New Name: ");
                    updateStudent.setName(scanner.nextLine());
                    System.out.print("Enter New City: ");
                    updateStudent.setCity(scanner.nextLine());
                    studentDao.updateStudent(updateStudent);
                    System.out.println("✅ Student updated.");
                } else {
                    System.out.println("❌ Student not found.");
                }
                break;

            case 5:
                System.out.print("Enter ID to delete: ");
                int deleteId = scanner.nextInt();
                studentDao.deleteStudent(deleteId);
                System.out.println("✅ Student deleted if existed.");
                break;

            case 6:
                go = false;
                System.out.println("👋 Exiting...");
                break;

            default:
                System.out.println("❌ Invalid choice.");
        }

        }

        scanner.close();
    }
}
