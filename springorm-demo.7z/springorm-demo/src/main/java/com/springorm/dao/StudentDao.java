package com.springorm.dao;

import com.springorm.entity.Student;
import java.util.List;

public interface StudentDao {
    int insert(Student student);
    Student getStudent(int studentId);
    List<Student> getAllStudents();
    void updateStudent(Student student);
    void deleteStudent(int studentId);
}
