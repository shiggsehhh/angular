package com.springorm.dao.impl;

import com.springorm.dao.StudentDao;
import com.springorm.entity.Student;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class StudentDaoImpl implements StudentDao {

    private HibernateTemplate hibernateTemplate;

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }

    @Transactional
    public int insert(Student student) {
        return (Integer) hibernateTemplate.save(student);
    }

    @Transactional
    public Student getStudent(int studentId) {
        return hibernateTemplate.get(Student.class, studentId);
    }

    @Transactional
    public List<Student> getAllStudents() {
        return hibernateTemplate.loadAll(Student.class);
    }

    @Transactional
    public void updateStudent(Student student) {
        hibernateTemplate.update(student);
    }

    @Transactional
    public void deleteStudent(int studentId) {
        Student student = hibernateTemplate.get(Student.class, studentId);
        if (student != null) {
            hibernateTemplate.delete(student);
        }
    }
}
