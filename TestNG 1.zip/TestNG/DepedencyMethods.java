package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

/*
 * By default TestNG executes all tests either the depedent methods fails or pass
 * to overcome this depedentOnMethods is introduced id the depedent method fails
 * then it skips remaining methods			
 * */
public class DepedencyMethods {

	@Test(priority = 1)
	void openApp() {
		Assert.assertTrue(true);
	}
	
	@Test(priority = 2, dependsOnMethods = {"openApp"})
	void login() {
		Assert.assertTrue(false);
	}
	
	@Test(priority = 3,dependsOnMethods = {"login"})
	void search() {
		Assert.assertTrue(true);
	}
	
	@Test(priority = 4, dependsOnMethods = {"login"})
	void advSearch() {
		Assert.assertTrue(true);
	}
	
	@Test(priority = 5,dependsOnMethods = {"login"})
	void logout() {
		Assert.assertTrue(true);
	}
}
