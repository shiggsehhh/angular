package TestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AllAnottations {
	
	@BeforeSuite
	void beforeSuite() {
		System.out.println("Before Suite");
	}
	
	@AfterSuite
	void AfterSuite() {
		System.out.println("After Suite");
	}
	
	@BeforeTest
	void beforeTest() {
		System.out.println("Before test");
	}
	@AfterTest
	void afterTest() {
		System.out.println("After test");
	}
	
	@BeforeClass
	void Login() {
		System.out.println("Before Class");
	}
	
	@AfterClass
	void LogOut() {
		System.out.println("After Class");
	}
	
	@BeforeMethod
	void BeforeMethod() {
		System.out.println("Before Method");
	}
	
	@AfterMethod
	void AfterMethod() {
		System.out.println("After Method");
	}
	
	@Test(priority = 1)
	void search() {
		System.out.println("TestCase 1");
	}
	
	@Test(priority = 2)
	void advSearch() {
		System.out.println("TestCase 2");
	}


}
