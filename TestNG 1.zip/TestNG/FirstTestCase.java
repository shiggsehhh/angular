package TestNG;

/* 
	TestNG -Test New Generation 
	
	java based unit testing tool.
	
	Advantages:
	-----
	1) Test cases & test suites
	2) Grouping of test cases.
	3) Prioritize
	4) Parameterization
	5) parallel testing
	6) Reports
	
	TestNG configuration
	-----------------
	1) Install testng in eclipse
	2) add testng library to build path / add testng dependency in pom.xml
	
	
	@Test   - annotation
	
	1) TestNG execute test methods based on alphabetical order.
	2) @Test(priority=num)  controls the order of execution.
	3) Once you provide priorty to the test methods, then order of methods is not considered.
	4) priorities can be random numbers( no need to have consecutive numbers)
	5) If you dont provide priority then default value is Zero (0).
	6) If the priorities are same then again execute methods in alphabetical order.
	7) Negitive values are allowed in priority.
	8)  TestNG execute test methods only if they are having @Test annotation.

 */
import org.testng.annotations.Test;

public class FirstTestCase {

	@Test(priority = 1)
	void openApp() {
		System.out.println("Opening App");
	}
	
	@Test(priority = 2)
	void login() {
		System.out.println("Login");
	}
	
	@Test (priority = 3)
	void Logout() {
		System.out.println("Log Out");
	}
}
