package TestNG;

import org.testng.annotations.Test;

public class SignUpTests {

	@Test(priority = 1,groups = {"regression"})
	void SignUpByEmail() {
		System.out.println("SignUp By Email");
	}

	@Test(priority = 2,groups = {"regression"})
	void SignUpByFaceBook() {
		System.out.println("SignUp By FaceBook");
	}

	@Test(priority = 3,groups = {"regression"})
	void SignUpByTwitter() {
		System.out.println("SignUp By Twitter");
	}
}
