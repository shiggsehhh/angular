package TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/*	parallel testing using xml file
	-----------------
	
	step1) created test case
	step 2) create xml file then run test case through xml
	step3 ) passed browser name, url as parameters from xml file to setup() method
	step4 ) execute test case on chrome,firefox & Edge (serial execution)
	step5 ) execute test case on chrome,firefox & edge ( parallel execution)
*/
public class Parameterization {
	
	WebDriver driver;

	@BeforeClass
	@Parameters({"browser"})// parameter name in xml
	void setUp(String br) throws InterruptedException {
		switch(br) {
		case "chrome": driver = new ChromeDriver();break;
		case "edge": driver = new EdgeDriver();break;
		default:System.out.println("Invalid Browser");return;
		}
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@Test(priority = 1)
	void testLogo() throws InterruptedException {
		
		 boolean status = driver.findElement(By.xpath("//*[@alt = 'company-branding']")).isDisplayed();
		 Assert.assertEquals(status, true);
	}
	
	
	@Test(priority = 2)
	void testTitle() {
		 Assert.assertEquals(driver.getTitle(), "OrangeHRM");
	}
	
	@AfterClass
	void close() {
		driver.quit();
	}
	
	
}
