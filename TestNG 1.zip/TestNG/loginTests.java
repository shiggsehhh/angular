package TestNG;

import org.testng.annotations.Test;

public class loginTests {

	@Test(priority = 1,groups = {"sanity"})
	void loginByEmail() {
		System.out.println("Login By Email");
	}

	@Test(priority = 2,groups = {"sanity"})
	void loginByFaceBook() {
		System.out.println("Login By FaceBook");
	}

	@Test(priority = 3,groups = {"sanity"})
	void loginByTwitter() {
		System.out.println("Login By Twitter");
	}

	
}
