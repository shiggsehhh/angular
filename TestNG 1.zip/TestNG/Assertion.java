package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Assertion {

	@Test
	void testTitle() {
		
		String actTitle = "openShop";
		String expTitle = "openCart";
		
		// when we use conditional statement if the testMethod is failed it shows passed
//		if(actTitle.equals(expTitle)) {
//			System.out.println("Passed");
//		}
//		else {
//			System.out.println("Failed");
//		}
		
		//to overCome above issue assert is used
		//Assert.assertEquals(expTitle, actTitle);
		
		// Assertion + conditional Statement
		if(actTitle.equals(expTitle)) {
			System.out.println("Passed");
			Assert.assertTrue(true);
			
		}
		else {
			System.out.println("Failed");
			Assert.assertTrue(false);
		}
	}
}
