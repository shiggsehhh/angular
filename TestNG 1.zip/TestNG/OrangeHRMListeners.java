package TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

/*
	TestNG Listeners
	----
	
	1) create test case
	2) create listener class
	3) create xml file and include both test case & listener class
	
	Listeners class can be integrated to test by using @Listeners and xml file <listeners>
*/

//@Listeners(TestNG.Listeners.class)
public class OrangeHRMListeners {

	WebDriver driver;
	  
	@Test(priority = 1)
	void openApp() {
		
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		Assert.assertTrue(true);
	}
	
	@Test(priority = 2)
	void testTitle() {
		
		String title = driver.getTitle();
		if(title.equalsIgnoreCase("Orange")) {
			System.out.println("TestCase Passed");
			
		}
		else
		Assert.assertTrue(false);
				
	}
	@Test(priority = 3,dependsOnMethods = {"testTitle"})
	void Login() {
		
		driver.findElement(By.xpath("//*[@name = 'username']")).sendKeys("Admin");
		driver.findElement(By.xpath("//*[@name = 'password']")).sendKeys("admin123");
		driver.findElement(By.xpath("//*[@type = 'submit']")).click();
		Assert.assertTrue(true);
	}
	
	@Test(priority = 4)
	void close() {
		
		driver.quit();
		Assert.assertTrue(true);
	}
}
