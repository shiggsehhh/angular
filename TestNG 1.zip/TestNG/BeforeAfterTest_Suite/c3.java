package TestNG.BeforeAfterTest_Suite;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class c3 {

	@Test
	void test() {
		System.out.println("Test case from C3");
	}
	
	@BeforeSuite
	void beforeSuite() {
		System.out.println("Before Suite");
	}
	
	@AfterSuite
	void AfterSuite() {
		System.out.println("After Suite");
	}
}
