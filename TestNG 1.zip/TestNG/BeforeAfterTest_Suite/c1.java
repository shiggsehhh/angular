package TestNG.BeforeAfterTest_Suite;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class c1 {

	@Test
	void test() {
		System.out.println("Test case from C1");
	}
	
	
}
