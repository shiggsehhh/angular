package TestNG.BeforeAfterTest_Suite;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class c2 {

	@Test
	void test() {
		System.out.println("Test case from C2");
	}
	
	
}
