package TestNG.BeforeAfterTest_Suite;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class test {

	
	@BeforeTest
	void beforeTest() {
		System.out.println("Before test");
	}
	
	@AfterTest
	void afterTest() {
		System.out.println("After test");
	}
}
