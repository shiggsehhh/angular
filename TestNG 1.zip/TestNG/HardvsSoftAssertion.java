package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

/*
  HardAssertion:
  		Assert is a class and methods are static (ie -> No need to create obj)
  		the lines which are written after the hard assertion did not get executed
  SoftAssertion:
  		the lines which are written after the soft assertion will get executed
  		obj need to be created to access the methods
  		assertAll() method is mandatory at last in soft assertion
 */

public class HardvsSoftAssertion {

	@Test
	void testHardAssertion() {
		System.out.println("Testing....");
		System.out.println("Testing....");
		Assert.assertEquals(1, 2);
		System.out.println("Testing....");
		System.out.println("Testing....");
	}
	
	//@Test
		void testSoftAssertion() {
			System.out.println("Testing....");
			System.out.println("Testing....");
			
			SoftAssert sa = new SoftAssert();
			sa.assertEquals(1, 2);
			
			System.out.println("Testing....");
			System.out.println("Testing....");
			sa.assertAll(); // if not written if cond is failed it shows test is passed 
		}
}
