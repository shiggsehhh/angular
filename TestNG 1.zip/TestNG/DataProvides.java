package TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProvides {
	
	WebDriver driver;
	
	@BeforeClass
	void setUp() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@Test(dataProvider = "dp")
	void testLogin(String email,String pass) throws InterruptedException {
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@name = 'username']")).sendKeys(email);
		driver.findElement(By.xpath("//*[@name = 'password']")).sendKeys(pass);
		driver.findElement(By.xpath("//*[@type = 'submit']")).click();
		String title  = driver.getTitle();
		if(title.equals("OrangeHRM")) {
			driver.findElement(By.xpath("//*[@class = 'oxd-topbar-header-userarea']/ul")).click();
			driver.findElement(By.linkText("Logout")).click();
			Assert.assertTrue(true);
		}
		else {
			Assert.fail();
		}
	}
	
	@AfterClass
	void close() {
		driver.quit();
	}
	
	@DataProvider(name = "dp",indices = {1,2}) // indices -> to specify the input
	Object[][] loginData() {
		
		Object[][] data = {
				
				{"Admin1","admin1233"},
				{"Admin","admin123"},
				{"Admin2","admin1235"}
		};
		return data;
	}
}
